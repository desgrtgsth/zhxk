package com.zh.zhxk.service;

import java.util.ArrayList;

import com.zh.zhxk.bean.Teacher;
import com.zh.zhxk.dao.TeacherDao;
import com.zh.zhxk.dao.implJdbc.TeacherDaoJdbcImp;

public class TeacherService {
private TeacherDao teacherDao = new TeacherDaoJdbcImp();
  public ArrayList<Teacher> findAllTeacher() {
	  return teacherDao.findAllTeacher();
}
public ArrayList<Teacher> findTeacher(String name, String sex, String phone) {
	// TODO Auto-generated method stub
	return teacherDao.findTeacher(name,sex,phone);
}
public void saveOrUpdate(Teacher teacher) {
	teacherDao.saveOrUpdate(teacher);
	
}
public Teacher findTeacherById(long id) {		
	return teacherDao.findTeacherById(id);
}
public void deleteById(Long id) {
	// TODO Auto-generated method stub
	teacherDao.deleteById(id);
}

}
