package com.zh.zhxk.service;

import java.util.ArrayList;

import com.zh.zhxk.bean.Student;
import com.zh.zhxk.dao.StudentDao;
import com.zh.zhxk.dao.implJdbc.StudentDaoJdbcImp;

public class StudentService {
private StudentDao studentDao = new StudentDaoJdbcImp();
  public ArrayList<Student> findAllStudent() {
	  return studentDao.findAllStudent();
}
public ArrayList<Student> findStudent(String name, String sex, String age, String phone) {
	// TODO Auto-generated method stub
	return studentDao.findStudent(name,sex,age,phone);
}
public void saveOrUpdate(Student student) {
	studentDao.saveOrUpdate(student);
	
}
public Student findStudentById(long id) {		
	return studentDao.findStudentById(id);
}
public void deleteById(Long id) {
	// TODO Auto-generated method stub
	studentDao.deleteById(id);
}
}
