package com.zh.zhxk.dao.implJdbc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.eclipse.jdt.internal.compiler.ast.ThisReference;

import com.sun.xml.internal.bind.v2.runtime.Name;
import com.zh.zhxk.bean.Student;
import com.zh.zhxk.bean.Teacher;
import com.zh.zhxk.dao.StudentDao;

public class StudentDaoJdbcImp implements StudentDao {
	private static final String driver = "com.mysql.jdbc.Driver";
    private static final String url = "jdbc:mysql://localhost:3306/scs?CharSet=utf8&useUnicode=true&characterEncoding=utf-8&autoReconnect=true";
	private static final String username = "root";
	private static final String password = "123456";
	
	@Override
	public ArrayList<Student> findAllStudent() {
		ArrayList<Student> arrayList = new ArrayList<>();
		try {
			Class.forName(driver);
			Connection connection = DriverManager.getConnection(url, username , password);
			String sql = "SELECT id, name, sex, age, phone FROM scs.student";
			PreparedStatement prepareStatement = connection.prepareStatement(sql);
			ResultSet resultSet = prepareStatement.executeQuery();
			while (resultSet.next()) {
				Student student = new Student();
				student.setId(resultSet.getLong(1));
				student.setName(resultSet.getString(2));
				student.setSex(resultSet.getString(3));
				student.setAge(resultSet.getString(4));
				student.setPhone(resultSet.getString(5));
				arrayList.add(student);				
			}
			}catch (ClassNotFoundException | SQLException e) {		
				e.printStackTrace();
			}
		return arrayList;
	}
	
	@Override
	public ArrayList<Student> findStudent(String name, String sex, String age, String phone) {
		ArrayList<Student> arrayList = new ArrayList<>();
		try {
			Class.forName(driver);
			Connection connection = DriverManager.getConnection(url, username , password);
			String sql = "SELECT id, name, sex, age, phone FROM scs.student where 1=1";
			sql += name == "" ? " and 1=? " : " and name = ?";
			sql += sex == "" ? " and 1=? " : " and sex = ?";
			sql += age == "" ? " and 1=? " : " and age = ?";
			sql += phone == "" ? " and 1=? " : " and phone = ?";
//			System.out.println(sql);
			PreparedStatement prepareStatement = connection.prepareStatement(sql);
			if (name == "") {
				prepareStatement.setInt(1, 1);
			} else {
				prepareStatement.setString(1, name);
			}
			if (sex == "") {
				prepareStatement.setInt(2, 1);
			} else {
				prepareStatement.setString(2, sex);
			}
			if (age == "") {
				prepareStatement.setInt(3, 1);
			} else {
				prepareStatement.setString(3, age);
			}
			if (phone == "") {
				prepareStatement.setInt(4, 1);
			} else {
				prepareStatement.setString(4, phone);
			}
//			System.out.println(prepareStatement.toString());
			ResultSet resultSet = prepareStatement.executeQuery();
			while (resultSet.next()) {
				Student student = new Student();
				student.setId(resultSet.getLong(1));
				student.setName(resultSet.getString(2));
				student.setSex(resultSet.getString(3));
				student.setAge(resultSet.getString(4));
				student.setPhone(resultSet.getString(5));
				arrayList.add(student);				
			}
			}catch (ClassNotFoundException | SQLException e) {		
				e.printStackTrace();
			}
		return arrayList;
	}


	@Override
	public void saveOrUpdate(Student student) {
		try {
			Class.forName(driver);
			Connection connection = DriverManager.getConnection(url, username , password);
			//判断student的id是否为空，如果不为空，就是更新，否则就是插入
			String sql = null;
			if (student.getId() != null) {
				sql = "UPDATE student set name = ?, sex = ?, age = ?, phone = ? where id = ?;";
			} else {
				sql = "INSERT INTO scs.student ( name, sex, age, phone) VALUES(?,?,?,?);";
			}
			
			PreparedStatement prepareStatement = connection.prepareStatement(sql);
			prepareStatement.setString(1, student.getName());
			prepareStatement.setString(2, student.getSex());
			prepareStatement.setString(3, student.getAge());
			prepareStatement.setString(4, student.getPhone());
			if (student.getId() != null) {
				prepareStatement.setLong(5, student.getId());
			}
			int executeUpdate = prepareStatement.executeUpdate();
			
			}catch (ClassNotFoundException | SQLException e) {		
				e.printStackTrace();
				throw new RuntimeException(e);
			}

	}

	@Override
	public Student findStudentById(Long id) {
		Student student = null;
		try {
			Class.forName(driver);
			Connection connection = DriverManager.getConnection(url, username , password);
			String sql = "SELECT id, name, sex, age, phone FROM scs.student where id = ?";
			PreparedStatement prepareStatement = connection.prepareStatement(sql);
			prepareStatement.setLong(1, id);
			ResultSet resultSet = prepareStatement.executeQuery();
			if (resultSet.next()) {
				student = new Student();
				student.setId(resultSet.getLong(1));
				student.setName(resultSet.getString(2));
				student.setSex(resultSet.getString(3));
				student.setAge(resultSet.getString(4));
				student.setPhone(resultSet.getString(5));		
			}
			}catch (ClassNotFoundException | SQLException e) {		
				e.printStackTrace();
			}
		return student;
	}

	 @Override
	  public void deleteById(Long id) {
	    try {
	      Class.forName(driver);
	      Connection connection = DriverManager.getConnection(url, username , password);      
	      String sql = "DELETE FROM  scs.student WHERE id = ? ";
	  
	      PreparedStatement prepareStatement = connection.prepareStatement(sql);
	      prepareStatement.setLong(1, id);

	       int executeUpdate = prepareStatement.executeUpdate();
	      
	      }catch (ClassNotFoundException | SQLException e) {    
	        e.printStackTrace();
	        throw new RuntimeException();
	      }    
	 }
	 
	  public static void main(String[] args) {
		    StudentDaoJdbcImp studentDaoJdbcImp = new StudentDaoJdbcImp();
		    
		    studentDaoJdbcImp.deleteById((long) 18);

		  }
}
