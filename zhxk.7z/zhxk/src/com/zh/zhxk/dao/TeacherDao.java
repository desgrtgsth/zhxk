package com.zh.zhxk.dao;

import java.util.ArrayList;

import com.zh.zhxk.bean.Teacher;

public interface TeacherDao {
	public ArrayList<Teacher>findAllTeacher();

	public ArrayList<Teacher> findTeacher(String name, String sex, String phone);

	public void saveOrUpdate(Teacher teacher);

	public Teacher findTeacherById(Long id);

	public void deleteById(Long id);

}
