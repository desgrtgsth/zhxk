package com.zh.zhxk.dao;

import java.util.ArrayList;

import com.zh.zhxk.bean.Student;

public interface StudentDao {
	public ArrayList<Student>findAllStudent();

	public ArrayList<Student> findStudent(String name, String sex, String age, String phone);

	public void saveOrUpdate(Student student);

	public Student findStudentById(Long id);

	public void deleteById(Long id);

}
