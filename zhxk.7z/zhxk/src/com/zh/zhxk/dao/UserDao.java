package com.zh.zhxk.dao;

public interface UserDao {
            com.zh.zhxk.bean.Users findUserByName(String name);//接口里给的是抽象方法
}