package com.zh.zhxk.web.ListenerAndFilter;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class CommonListerner
 *
 */
@WebListener
public class CommonListerner implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public CommonListerner() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
        ServletContext servletContext = sce.getServletContext();
        String ctx = servletContext.getContextPath();
        servletContext.setAttribute("ctx", ctx);
        servletContext.setAttribute("res", ctx + "/resources");
        servletContext.setAttribute("js", ctx + "/resoueces/js");
        servletContext.setAttribute("css", ctx + "/resoueces/themes/css");
    }
	
}
