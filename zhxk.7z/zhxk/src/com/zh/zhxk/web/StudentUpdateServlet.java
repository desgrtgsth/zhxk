package com.zh.zhxk.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zh.zhxk.bean.Student;
import com.zh.zhxk.service.StudentService;

/**
 * Servlet implementation class StudentAddServlet
 */
@WebServlet("/student_add")
public class StudentUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	StudentService studentService = new StudentService();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String idString = request.getParameter("id");
		if (idString != null) {
			long id = Long.valueOf(idString);
			Student student = studentService.findStudentById(id);
			request.setAttribute("student", student);
		}	
		request.getRequestDispatcher("/resources/common/student_add.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		Student student = new Student();
		String idString = request.getParameter("id");
		String name = request.getParameter("name");
		String age = request.getParameter("age");
		String phone = request.getParameter("phone");
		String sex = request.getParameter("sex");
		if (idString != "" ) {
			Long id = Long.valueOf(idString);
			student.setId(id);
		}
		student.setName(name);
		student.setAge(age);
		student.setPhone(phone);
		student.setSex(sex);
		String msg;
		try {
			studentService.saveOrUpdate(student);
			msg = "{\"statusCode\":\"200\", \"message\":\"操作成功\", \"navTabId\":\"student_list\","
					+ " \"callbackType\":\"closeCurrent\"}";
		} catch (Exception e) {
			msg = "{\"statusCode\":\"300\", \"message\":\"操作失败\"}";
		}
		response.getWriter().print(msg);
		
	}

}
