package com.zh.zhxk.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zh.zhxk.service.TeacherService;

/**
 * Servlet implementation class TeacherDeleteServlet
 */
@WebServlet("/teacher_delete")
public class TeacherDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    TeacherService teacherService = new TeacherService();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TeacherDeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idString = request.getParameter("id");
        Long id = Long.valueOf(idString);
        String msg;
        try {
          teacherService.deleteById(id);
          msg = "{\"statusCode\":\"200\", \"message\":\"操作成功\", \"navTabId\":\"teacher_list\", \"callbackType\":\"closeCurrent\"}";
          
        } catch (Exception e) {
          // TODO: handle exception
          msg = "{\"statusCode\":\"300\", \"message\":\"操作失败\"}";
        }
        response.getWriter().print(msg);
      }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
